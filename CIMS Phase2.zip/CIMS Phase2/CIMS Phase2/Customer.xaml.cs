﻿using CIMS_BAL;
using CIMS_Entities;
using CIMS_Exceptions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CIMS_Phase2
{
    /// <summary>
    /// Interaction logic for List.xaml
    /// </summary>
    public partial class Customer : Window
    {
        public Customer()
        {
            InitializeComponent();
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            GetManufacutureNames();
            GetTypes();
        }
        private void BtnSearchByModel_Click(object sender, RoutedEventArgs e)
        {
            SearchCarByModel();
        }

        private void BtnShowCars_Click(object sender, RoutedEventArgs e)
        {
            ShowCars();
        }

        private void Btnback_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
            Admin admin = new Admin();
            admin.Show();
        }

       
        private void SearchCarByModel()
        {
            try
            {
                string model =txtModel.Text;
                if (txtModel.Text != "")
                {
                    Car objCar = CarBAL.SearchCarByModelBAL(model);
                    if (objCar != null)
                    {
                        cmbname.Text = objCar.ManufacturerName.ToString();
                        cmbType.Text = objCar.Type.ToString();
                        txtEngine.Text = objCar.Engine;
                        txtBHP.Text = objCar.BHP.ToString();
                        cmbType.Text = objCar.Transmission.ToString();
                        txtMileage.Text = objCar.Mileage.ToString();
                        txtseats.Text = objCar.Seats.ToString();
                        txtAirBags.Text = objCar.AirBagDetails;
                        txtBootSpace.Text = objCar.BootSpace.ToString();
                        txtPrice.Text = objCar.Price.ToString();
                    }
                    else
                    {
                        MessageBox.Show("No Car records available.");
                    }
                }
                else
                    MessageBox.Show("Please Enter Model");

            }
            catch (CarExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void ShowCars()
        {
            try
            {
                string name = cmbname.Text;
                string type = cmbType.Text;
                if (cmbname.Text != "" || cmbType.Text != "")
                {
                    List<Car> objCars = CarBAL.ShowCarsBAL(name, type);
                    if (objCars != null)
                    {
                        dgcars.ItemsSource = objCars;
                    }
                    else
                    {
                        MessageBox.Show("No records available.");
                    }
                }
                else
                    MessageBox.Show("Please Enter type And Manufacturer");
                }
             catch (CarExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
}
        private void GetManufacutureNames()
        {
            try
            {
                DataTable designationList = CarBAL.GetManufacturerBAL();
                cmbname.ItemsSource = designationList.DefaultView;
                cmbname.DisplayMemberPath = designationList.Columns[1].ColumnName;
                cmbname.SelectedValuePath = designationList.Columns[0].ColumnName;
            }
            catch (CarExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void GetTypes()
        {
            try
            {
                DataTable designationList = CarBAL.GetTypesBAL();
                cmbType.ItemsSource = designationList.DefaultView;
                cmbType.DisplayMemberPath = designationList.Columns[1].ColumnName;
                cmbType.SelectedValuePath = designationList.Columns[0].ColumnName;
            }
            catch (CarExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnSearchbyModel_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void BtnList_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Btnback_Click_1(object sender, RoutedEventArgs e)
        {

        }
    }
}
