﻿using CIMS_BAL;
using CIMS_Entities;
using CIMS_Exceptions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CIMS_Phase2
{
    /// <summary>
    /// Interaction logic for List.xaml
    /// </summary>
    public partial class DisplayCars : Window
    {
        public DisplayCars()
        {
            InitializeComponent();
        }
        private void BtnSearchByType_Click(object sender, RoutedEventArgs e)
        {
            ShowCarsBytype();
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetManufacutureNames();
            GetTypes();
        }
        private void Btnback_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
            Admin admin = new Admin();
            admin.Show();
        }

        private void BtnListCars_Click_1(object sender, RoutedEventArgs e)
        {
            ListAllCars();
        }
        private void ShowCarsBytype()
        {
            try
            {
                string name = cmbname.Text;
                string type = cmbtype.Text;
                if (cmbname.Text != "" || cmbtype.Text != "")
                {
                    List<Car> objCars = CarBAL.ShowCarsBAL(name, type);
                    if (objCars != null)
                    {
                        dgList.ItemsSource = objCars;
                    }
                    else
                    {
                        MessageBox.Show("No records available.");
                    }
                }
                else
                    MessageBox.Show("Please Enter type And Manufacturer");
            }
            catch (CarExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void ListAllCars()
        {
            List<Car> CarList = CarBAL.ListCarsBAL();
            dgList.ItemsSource = CarList;
        }

        private void GetManufacutureNames()
        {
            try
            {
                DataTable designationList = CarBAL.GetManufacturerBAL();
                cmbname.ItemsSource = designationList.DefaultView;
                cmbname.DisplayMemberPath = designationList.Columns[1].ColumnName;
                cmbname.SelectedValuePath = designationList.Columns[0].ColumnName;
            }
            catch (CarExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void GetTypes()
        {
            try
            {
                DataTable designationList = CarBAL.GetTypesBAL();
                cmbtype.ItemsSource = designationList.DefaultView;
                cmbtype.DisplayMemberPath = designationList.Columns[1].ColumnName;
                cmbtype.SelectedValuePath = designationList.Columns[0].ColumnName;
            }
            catch (CarExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
