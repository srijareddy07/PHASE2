﻿using CIMS_BAL;
using CIMS_Entities;
using CIMS_Exceptions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CIMS_Phase2
{
    /// <summary>
    /// Interaction logic for Update.xaml
    /// </summary>
    public partial class Operations : Window
    {
        public Operations()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            GetManufacutureNames();
            GetTypes();
            GetTransmission();
        }
        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            AddCar();
        }
        private void BtUpdateCar_Click(object sender, RoutedEventArgs e)
        {
            UpdateCar();
        }       

        private void BtDeleteCar_Click(object sender, RoutedEventArgs e)
        {
            DeleteCar();
        }

        private void BtnSearchCarByModel_Click(object sender, RoutedEventArgs e)
        {
            SearchCarByModel();
        }
        private void AddCar()
        {
            try
            {
                bool CarAdded = false;
                if (txtModel.Text != string.Empty && txtAirbags.Text != string.Empty && txtBHP.Text != string.Empty && txtBootSpace.Text != string.Empty && txtEngine.Text != string.Empty && txtMileage.Text != string.Empty && txtPrice.Text != string.Empty && txtSeats.Text != string.Empty && cmbManufacturerName.Text != string.Empty && cmbTransmissionId.Text != string.Empty && cmbType.Text != string.Empty)
                {
                    Car objCar = new Car();
                    objCar.ManufacturerName = Convert.ToInt32(cmbManufacturerName.SelectedValue);
                    objCar.Model = txtModel.Text;
                    objCar.Type = Convert.ToInt32(cmbType.SelectedValue);
                    objCar.Engine = txtEngine.Text;
                    objCar.BHP = Convert.ToInt32(txtBHP.Text);
                    objCar.Transmission = Convert.ToInt32(cmbTransmissionId.SelectedValue);
                    objCar.Mileage = Convert.ToInt32(txtMileage.Text);
                    objCar.Seats = Convert.ToInt32(txtSeats.Text);
                    objCar.AirBagDetails = txtAirbags.Text;
                    objCar.BootSpace = Convert.ToInt32(txtBootSpace.Text);
                    objCar.Price = Convert.ToDouble(txtPrice.Text);
                    CarAdded = CarBAL.AddCarBAL(objCar);
                    if (CarAdded == true)
                    {
                        MessageBox.Show("Car Details added successfully. CarId:");
                    }
                    else
                    {
                        MessageBox.Show("Car Details couldn't be added.");
                    }
                }
                else
                    MessageBox.Show("All Feilds are Mandatory");
            }
            catch (CarExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void UpdateCar()
        {
            try
            {              
                    //                   
                string modelname = txtModel.Text;
                Car car = null;
                bool CarUpdated;
                if (txtModel.Text != "")
                {
                    car = CarBAL.SearchCarByModelBAL(modelname);
                    if (car != null)
                    {
                        Car objCar = new Car();
                        objCar.ManufacturerName = Convert.ToInt32(cmbManufacturerName.SelectedValue);
                        objCar.Model = txtModel.Text;
                        objCar.Type = Convert.ToInt32(cmbType.SelectedValue);
                        objCar.Engine = txtEngine.Text;
                        objCar.BHP = Convert.ToInt32(txtBHP.Text);
                        objCar.Transmission = Convert.ToInt32(cmbTransmissionId.SelectedValue);
                        objCar.Mileage = Convert.ToInt32(txtMileage.Text);
                        objCar.Seats = Convert.ToInt32(txtSeats.Text);
                        objCar.AirBagDetails = txtAirbags.Text;
                        objCar.BootSpace = Convert.ToInt32(txtBootSpace.Text);
                        objCar.Price = Convert.ToDouble(txtPrice.Text);
                        CarUpdated = CarBAL.UpdateCarBAL(objCar);
                        if (CarUpdated == true)
                        {
                            MessageBox.Show("Car Details updated successfully");
                        }
                        else
                        {
                            MessageBox.Show("Car Details couldn't be updated.");
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Please enter Model to Update");
                }                    
            }
            catch (CarExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }           
            }
        private void DeleteCar()
        {
            try
            {

                string model = txtModel.Text;
                Car car = null;
                bool Cardeleted  = false;
                if (txtModel.Text != "")
                {
                    car = CarBAL.SearchCarByModelBAL(model);
                    if (car != null)
                    {
                        MessageBoxResult dr = MessageBox.Show("Are you sure you want to delete  the car?", "Confirmation", MessageBoxButton.YesNo);
                        if (dr == MessageBoxResult.Yes)
                        {
                            Cardeleted = CarBAL.DeleteCarBAL(car.Model);
                        }
                        if (Cardeleted )
                            MessageBox.Show("Car Details are deleted successfully");
                        else
                           MessageBox.Show("Not deleted ");
                    }
                    else
                    {
                        MessageBox.Show("Car with given model is not found ");
                    }

                }
                else
                {
                    MessageBox.Show("Please enter Model to delete");
                }
            }
            catch (CarExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void SearchCarByModel()
        {
            try
            {
                string model;
                Car objCar;
                model = txtModel.Text;
                objCar = CarBAL.SearchCarByModelBAL(model);
                if (objCar != null)
                {
                    cmbManufacturerName.Text = objCar.ManufacturerName.ToString();
                    cmbType.Text = objCar.Type.ToString();
                    txtEngine.Text = objCar.Engine;
                    txtBHP.Text = objCar.BHP.ToString();
                    cmbType.Text = objCar.Transmission.ToString();
                    txtMileage.Text = objCar.Mileage.ToString();
                    txtSeats.Text = objCar.Seats.ToString();
                    txtAirbags.Text = objCar.AirBagDetails;
                    txtBootSpace.Text = objCar.BootSpace.ToString();
                    txtPrice.Text = objCar.Price.ToString();
                }
                else
                {
                    MessageBox.Show("Car with given model couldn't be found.");
                }
            }
            catch (CarExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }       
        }
        private void GetManufacutureNames()
        {
            try
            {
                DataTable designationList = CarBAL.GetManufacturerBAL();
                cmbManufacturerName.ItemsSource = designationList.DefaultView;
                cmbManufacturerName.DisplayMemberPath = designationList.Columns[1].ColumnName;
                cmbManufacturerName.SelectedValuePath = designationList.Columns[0].ColumnName;
            }
            catch (CarExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void GetTypes()
        {
            try
            {
                DataTable designationList = CarBAL.GetTypesBAL();
                cmbType.ItemsSource = designationList.DefaultView;
                cmbType.DisplayMemberPath = designationList.Columns[1].ColumnName;
                cmbType.SelectedValuePath = designationList.Columns[0].ColumnName;
            }
            catch (CarExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void GetTransmission()
        {
            CarBAL bal = new CarBAL();
            try
            {
                DataTable designationList = CarBAL.GetTransmissionBAL();
                cmbTransmissionId.ItemsSource = designationList.DefaultView;
                cmbTransmissionId.DisplayMemberPath = designationList.Columns[1].ColumnName;
                cmbTransmissionId.SelectedValuePath = designationList.Columns[0].ColumnName;
            }
            catch (CarExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Btnback_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
            Admin admin = new Admin();
            admin.Show();
        }

        

    }
}
